package br.fecapads.questao5;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private CheckBox cbCalabresa, cbMarguerita, cbPortuguesa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selecao_pizza);

        cbCalabresa = findViewById(R.id.cbCalabresa);
        cbMarguerita = findViewById(R.id.cbMarguerita);
        cbPortuguesa = findViewById(R.id.cbPortuguesa);
        Button btnConfirmarPizza = findViewById(R.id.btnConfirmarPizza);

        btnConfirmarPizza.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String tipoPizza = "";

                if (cbCalabresa.isChecked()) tipoPizza = "Calabresa";
                if (cbMarguerita.isChecked()) tipoPizza = "Marguerita";
                if (cbPortuguesa.isChecked()) tipoPizza = "Portuguesa";

                Intent intent = new Intent(MainActivity.this, SelecaoTamanhoPagamentoActivity.class);
                intent.putExtra("tipoPizza", tipoPizza);
                startActivity(intent);
            }
        });
    }
}
