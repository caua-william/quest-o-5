package br.fecapads.questao5;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.appcompat.app.AppCompatActivity;

public class SelecaoTamanhoPagamentoActivity extends AppCompatActivity {

    private RadioGroup rgTamanhoPizza, rgPagamento;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selecao_tamanho_pagamento);

        rgTamanhoPizza = findViewById(R.id.rgTamanhoPizza);
        rgPagamento = findViewById(R.id.rgPagamento);
        Button btnConfirmarTamanhoPagamento = findViewById(R.id.btnConfirmarTamanhoPagamento);

        btnConfirmarTamanhoPagamento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedTamanhoId = rgTamanhoPizza.getCheckedRadioButtonId();
                int selectedPagamentoId = rgPagamento.getCheckedRadioButtonId();

                RadioButton selectedTamanho = findViewById(selectedTamanhoId);
                RadioButton selectedPagamento = findViewById(selectedPagamentoId);

                String tipoPizza = getIntent().getStringExtra("tipoPizza");
                String tamanhoPizza = selectedTamanho.getText().toString();
                String metodoPagamento = selectedPagamento.getText().toString();

                Intent intent = new Intent(SelecaoTamanhoPagamentoActivity.this, ResumoPedidoActivity.class);
                intent.putExtra("tipoPizza", tipoPizza);
                intent.putExtra("tamanhoPizza", tamanhoPizza);
                intent.putExtra("metodoPagamento", metodoPagamento);
                startActivity(intent);
            }
        });
    }
}
