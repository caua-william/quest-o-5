package br.fecapads.questao5;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ResumoPedidoActivity extends AppCompatActivity {

    private TextView tvResumo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resumo_pedido);

        tvResumo = findViewById(R.id.tvResumo);

        String tipoPizza = getIntent().getStringExtra("tipoPizza");
        String tamanhoPizza = getIntent().getStringExtra("tamanhoPizza");
        String metodoPagamento = getIntent().getStringExtra("metodoPagamento");

        // Calcular o valor total com base no tamanho
        double valorTotal = 0.0;
        switch (tamanhoPizza) {
            case "Pequena":
                valorTotal = 20.0;
                break;
            case "Média":
                valorTotal = 30.0;
                break;
            case "Grande":
                valorTotal = 40.0;
                break;
        }

        // Exibindo o resumo do pedido
        tvResumo.setText("Pizza: " + tipoPizza + "\nTamanho: " + tamanhoPizza + "\nPagamento: " + metodoPagamento + "\nValor Total: R$" + valorTotal);

    }
}

